const mongoose = require("mongoose");
const validator = require("validator");

const PasswordValidator = require("password-validator");

// let regex = /^[A-Za-z0-9._%+-]+@northeastern\.edu$/;

const pass = new PasswordValidator();

pass
  .is()
  .min(8)
  .is()
  .max(50) // Maximum length 50
  .has()
  .uppercase() // Must have uppercase letters
  .has()
  .lowercase() // Must have lowercase letters
  .has()
  .digits() // Must have digits
  .has()
  .symbols() // Must have symbols
  .has()
  .not()
  .spaces() // Should not have spaces
  .is()
  .not()
  .oneOf(["Password123", "12345"]); // Blacklist these values

// const fullNameRegex = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
// let regexer = /^[A-Za-z0-9._%+-]+@northeastern\.edu$/;

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
});

//validations
function validateEmail(email) {
  let regex = /^[A-Za-z0-9._%+-]+@northeastern\.edu$/;
  if (regex.test(email) == false) {
    return false;
  } else {
    return true;
  }
}

// we will create a new collection
const User = new mongoose.model("User", userSchema);

module.exports = User;
