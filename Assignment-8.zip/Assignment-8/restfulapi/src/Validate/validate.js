const validatePassword=(password) => {
    let passwordValue = password;
    var password_regex1 = /^(?=.[A-Za-z])(?=.\d)(?=.[@$!%#?&])[A-Za-z\d@$!%*#?&]{8,}$/;

    if (password_regex1.test(passwordValue) == false) {
        return false;
    } else {
        return true;
    }

}

const validateEmail=(email) =>{
    let regex = /^[A-Za-z0-9._%+-]+@northeastern\.edu$/;
    if (regex.test(email) == false) {
        return false;
    } else {
        return true;
    }

}
model.exports = {validateEmail};

model.exports={validatePassword};
