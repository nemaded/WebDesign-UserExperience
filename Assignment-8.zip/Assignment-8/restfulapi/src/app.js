const express = require("express");
require("./db/conn");
const bcrypt = require("bcrypt");
const Student = require("./models/students");
const app = express();
const port = process.env.PORT || 3000;
app.use(express.json());
// CREATE A USER
app.post("/students", async (req, res) => {
  console.log(req.body); //gets the body from the postman body
  const user = new Student(req.body);
  const email = req.body.email;
  const name = req.body.name;
  const password = req.body.password;
  let emailError = validateEmail(email);
  let fullname = validateFullName(name);
  let validatePass = validatePassword(password);
  if (emailError && fullname && validatePass) {
    console.log("Valid Email");
    console.log("valid full name");
    console.log("validated password");
    const hashedPassword = await bcrypt.hash(password, 10);
    console.log(hashedPassword);

    const userExits = await Student.findOne({ email });
    if (userExits) {
      return res
        .status(420)
        .send("User already exists please try with other email");
    }
    try {
      let user = new Student({
        name: req.body.name,
        email: req.body.email,
        password: hashedPassword,
      });
      const CreateUser = await user.save();
      res.status(201).send(CreateUser);
    } catch (e) {
      res.status(400).send(e);
    }
  } else {
    res
      .status(420)
      .send(
        "Invalid details: password must contain 1 digit, 1 character,1uppercase,1lowercase and min length is 8 and Full name must contain 2 strings and email must have domain northeastern.edu"
      );
  }
});
//DELETE THE USER
app.delete("/students/:email", async (req, res) => {
  // Delete a user using email     // Check the user is present in database or not

  const email = req.params.email;
  console.log(email);
  try {
    // Find the user by email and delete them
    const deletedUser = await Student.findOneAndDelete({ email });
    console.log(`deleted email is ${email}`);
    // If the user was not found, return a 404 error
    if (!deletedUser) {
      return res.status(404).json({ message: "User not found" });
    }
    // Return a success message
    res.json({ message: "User deleted successfully" });
  } catch (err) {
    // If there was an error, return a 400 error
    res.status(400).json({ message: "Error deleting user" });
  }
});
//GET ALL THE USERS
app.get("/students", async (req, res) => {
  try {
    const Studentsdata = await Student.find();
    res.send(Studentsdata);
  } catch (e) {
    res.send(e);
  }
});
//GET USER BY ID
app.get("/students/:id", async (req, res) => {
  try {
    const _id = req.params.id;
    const Studentdata = await Student.findById(_id);
    console.log(Studentdata);
    if (!Studentdata) {
      return res.status(404).send();
    } else {
      res.send(Studentdata);
    }
    res.send(Studentdata);
  } catch (e) {
    res.status(500).send(e);
  }
});
//UPDATE NAME AND NAME USING ID
app.put("/students/:id", async (req, res) => {
  const { name, email, password } = req.body;

  // Check if the user exists in the database

  try {
    try {
      const user = await Student.findById(req.params.id);
    } catch (e) {
      return res
        .status(500)
        .json({ message: "user not found in the database" });
    }
    // console.log(user);

    // console.log(fullname);

    // Hash the new password and update the user's password field
    try {
      const user = await Student.findById(req.params.id);
      let fullname = validateFullName(name);
      let validatepass = validatePassword(password);
      console.log(password);
      console.log(validatepass);
      if (fullname) {
        const hashedPassword = await bcrypt.hash(user.password, 10);
        user.name = name;
        console.log(`name changed to ${user.name}`);
        if (validatepass) {
          user.password = hashedPassword;
        } else {
          return res
            .status(200)
            .json({ message: "Invalid request for password" });
        }
        await user.save();
        return res.status(200).json({ message: "request successfull" });
      } else {
        return res.status(200).json({ message: "Invalid request for name" });
      }
    } catch (e) {
      // const hashedPassword = await bcrypt.hash(user.password, 10);
      // user.password = hashedPassword;
      // res.send(user);
      // // Save the updated user to the database
      // await user.save();
      return res
        .status(404)
        .json({ message: "Check the entries and try again" });
    }

    //

    // return res.status(200).json({ message: "request updated successfully" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "Internal server error" });
  }
});
//VALIDATION FOR EMAIL
function validateEmail(email) {
  let regex = /^[A-Za-z0-9._%+-]+@northeastern\.edu$/;
  if (regex.test(email) == false) {
    return false;
  } else {
    return true;
  }
}
//VALIDATION FOR FULLNAME
function validateFullName(fullName) {
  const regex = /^[A-Za-z]+([- ]?[A-Za-z]+)*$/;
  return regex.test(fullName) && fullName.split(" ").length >= 2;
}
//VALIDATION FOR PASSWORD
function validatePassword(password) {
  // Password must be at least 8 characters long
  if (password.length < 8) {
    return false;
  }

  // Password must contain at least one lowercase letter
  if (!/[a-z]/.test(password)) {
    return false;
  }

  // Password must contain at least one uppercase letter
  if (!/[A-Z]/.test(password)) {
    return false;
  }

  // Password must contain at least one digit
  if (!/\d/.test(password)) {
    return false;
  }

  // Password must contain at least one special character
  if (!/[@$!%*#?&]/.test(password)) {
    return false;
  }

  // If all tests pass, password is considered strong
  return true;
}
// function encryptPassword(password) {
//   // Requiring module
//   const bcrypt = require("bcryptjs");

//   const hashedPassword = null;

//   // Encryption of the string password
//   bcrypt.genSalt(10, function (err, Salt) {
//     // The bcrypt is used for encrypting password.
//     bcrypt.hash(password, Salt, function (err, hash) {
//       if (err) {
//         return console.log("Cannot encrypt");
//       }

//       hashedPassword = hash;
//       console.log(hash);

//       bcrypt.compare(password, hashedPassword, async function (err, isMatch) {
//         // Comparing the original password to
//         // encrypted password
//         if (isMatch) {
//           console.log("Encrypted password is: ", password);
//           console.log("Decrypted password is: ", hashedPassword);
//         }

//         if (!isMatch) {
//           // If password doesn't match the following
//           // message will be sent
//           console.log("Not Encrypted");
//         }
//       });
//     });
//   });
// }
app.listen(port, () => {
  console.log(`connection is setup at ${port}`);
});
